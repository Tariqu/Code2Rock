import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ace-editor',
  templateUrl: './ace-editor.component.html',
  styleUrls: ['./ace-editor.component.scss']
})
export class AceEditorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
