import { Component, OnInit, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { Terminal } from 'xterm';
import { AttachAddon } from 'xterm-addon-attach';
import { FitAddon } from 'xterm-addon-fit';
import { SearchAddon, ISearchOptions } from 'xterm-addon-search';
import { WebLinksAddon } from 'xterm-addon-web-links';

@Component({
  selector: 'app-terminal',
  templateUrl: './terminal.component.html',
  styleUrls: ['./terminal.component.scss']
})
export class TerminalComponent implements OnInit,AfterViewInit {
  private term = new Terminal();
  private pid;
  private socketURL = 'ws://localhost:3000/terminals/';
  private socket;
  private fitAddon: FitAddon;
  private searchAddon: SearchAddon;
  @ViewChild('myTerminal',{static:false}) terminalContainer: ElementRef;

  constructor() { }
  ngOnInit() {
    this.fitAddon = new FitAddon();
    setTimeout(() => {
      this.updateTerminalSize();
  
      fetch('http://127.0.0.1:3000/terminals?cols=' + this.term.cols + '&rows=' + this.term.rows, {method: 'POST'}).then((res) => {
        res.text().then((processId) => {
          this.pid = processId;
          this.socketURL += processId;
          this.socket = new WebSocket(this.socketURL);
          this.socket.onopen = this.runRealTerminal();
        });
      });
    }, 0);
  }
  ngAfterViewInit(){
    this.runFakeTerminal();
  }
  updateTerminalSize(): void {
    const cols = this.term.cols;
    const rows = this.term.rows;
    const width = cols.toString() + 'px';
    const height = rows.toString() + 'px';
    this.terminalContainer.nativeElement.style.width = width;
    this.terminalContainer.nativeElement.style.height = height;
    this.fitAddon.fit();
  }
  prompt = () => {
    this.term.write('\r\n$ ');
  };
  createTerminal(): void {
    this.term.loadAddon(new WebLinksAddon());
    this.searchAddon = new SearchAddon();
    this.term.loadAddon(this.searchAddon);
    this.fitAddon = new FitAddon();
    this.term.loadAddon(this.fitAddon);
    this.term.onResize((size: { cols: number, rows: number }) => {
      if (!this.pid) {
        return;
      }
      const cols = size.cols;
      const rows = size.rows;
      const url = 'http://127.0.0.1:3000/terminals/' + this.pid + '/size?cols=' + cols + '&rows=' + rows;
      fetch(url, {method: 'POST'});
    });
    this.socketURL = 'ws://localhost:3000/terminals/';
    this.term.open(this.terminalContainer.nativeElement);
    this.fitAddon.fit();
    this.term.focus();
  }
  runRealTerminal(): void {
    this.term.loadAddon(new AttachAddon(this.socket));
    // term.loadAddon(new AttachAddon(socket, {inputUtf8: true}));
    // this.term._initialized = true;
  }
  
  runFakeTerminal(): void {
    this.term.open(this.terminalContainer.nativeElement);
    this.term.writeln('Welcome to Mindfire Solutions');
    // this.term.onKey((e: { key: string, domEvent: KeyboardEvent }) => {
    //   const ev = e.domEvent;
    //   const printable = !ev.altKey && !ev.ctrlKey && !ev.metaKey;
    //   if (ev.keyCode === 13) {
    //     this.prompt();
    //   } else if (ev.keyCode === 8) {
    //    // Do not delete the prompt
    //     if (this.term.buffer.cursorX > 2) {
    //       this.term.write('\b \b');
    //     }
    //   } else if (printable) {
    //     this.term.write(e.key);
    //   }
    // });
  }
  
}
